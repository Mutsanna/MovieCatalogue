package com.mutsanna.moviecatalogue.vo

enum class Status {

    SUCCESS,
    ERROR,
    LOADING

}