package com.mutsanna.moviecatalogue.data.source.remote

enum class StatusResponse {
    SUCCESS,
    EMPTY,
    ERROR
}